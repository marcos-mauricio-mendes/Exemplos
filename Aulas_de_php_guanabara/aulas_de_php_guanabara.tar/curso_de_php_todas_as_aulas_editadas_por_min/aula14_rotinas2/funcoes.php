
<?php

function ola(){


echo "<h1>Olá Mundo Maldido!!</h1>";



}

function mostraValor($v){


    echo "<h2> Acabei de receber o valor $v </h2>";


}

?>
