<!--exercicio de For-->
<html lag="pt-br">
<head>
    <title>Chamando Funções </title>
    <meta charset="utf-8">
	
	</head>
<body>

<p>Chamando funções em meu arquivo funcoes.php</p>

    <div>

<?php

include "funcoes.php";
    
    ola();
    mostraValor(4);


?>

    
</div>


</body>
</html>