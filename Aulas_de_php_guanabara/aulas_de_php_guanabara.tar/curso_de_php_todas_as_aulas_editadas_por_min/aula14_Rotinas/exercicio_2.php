<?php

//Calcula os valores de $x e $y e imprime ná tela

function soma ($a, $b) {
    
    return $a + $b;


}

$x = 3;
$y = 4;
$r = soma($x,$y);

echo "A soma entre $x e $y e igual a $r";


?>