<?php

//Calcula os valores e imprime ná tela

function soma ($a, $b) {

    $s = $a + $b;
    
    echo "<p>A soma vale $s</p> ";


}

soma(3, 4);
soma(8, 2);



$x = 9;
$y = 15;


soma($x, $y);

?>